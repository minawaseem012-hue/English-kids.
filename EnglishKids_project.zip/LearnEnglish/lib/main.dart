import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const LearnEnglishApp());

class Word {
  final String en, ar, emoji;
  const Word(this.en, this.ar, this.emoji);
}

const units = <String, List<Word>>{
  'Alphabet': [
    Word('Apple', 'تفاحة', '🍎'), Word('Ball', 'كرة', '⚽'),
    Word('Cat', 'قطة', '🐱'), Word('Dog', 'كلب', '🐶'),
    Word('Elephant', 'فيل', '🐘'), Word('Fish', 'سمكة', '🐟'),
  ],
  'Numbers': [
    Word('One', 'واحد', '1️⃣'), Word('Two', 'اثنان', '2️⃣'),
    Word('Three', 'ثلاثة', '3️⃣'), Word('Four', 'أربعة', '4️⃣'),
    Word('Five', 'خمسة', '5️⃣'),
  ],
  'Colors': [
    Word('Red', 'أحمر', '🔴'), Word('Blue', 'أزرق', '🔵'),
    Word('Green', 'أخضر', '🟢'), Word('Yellow', 'أصفر', '🟡'),
    Word('Purple', 'بنفسجي', '🟣'),
  ],
  'Animals': [
    Word('Cat', 'قطة', '🐱'), Word('Dog', 'كلب', '🐶'),
    Word('Lion', 'أسد', '🦁'), Word('Tiger', 'نمر', '🐯'),
    Word('Monkey', 'قرد', '🐵'), Word('Rabbit', 'أرنب', '🐰'),
  ],
  'Food': [
    Word('Apple', 'تفاحة', '🍎'), Word('Banana', 'موزة', '🍌'),
    Word('Bread', 'خبز', '🍞'), Word('Milk', 'حليب', '🥛'),
    Word('Pizza', 'بيتزا', '🍕'),
  ],
  'Family': [
    Word('Father', 'أب', '👨'), Word('Mother', 'أم', '👩'),
    Word('Brother', 'أخ', '👦'), Word('Sister', 'أخت', '👧'),
  ],
};

class LearnEnglishApp extends StatelessWidget {
  const LearnEnglishApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'English Kids',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorSchemeSeed: Colors.indigo,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int points = 0, stars = 0, completed = 0;
  int tab = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      points = p.getInt('points') ?? 0;
      stars = p.getInt('stars') ?? 0;
      completed = p.getInt('completed') ?? 0;
    });
  }

  Future<void> addReward() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('points', points + 10);
    await p.setInt('stars', stars + 1);
    await p.setInt('completed', completed + 1);
    setState(() {
      points += 10; stars += 1; completed += 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      LessonsPage(onComplete: addReward),
      const GamesPage(),
      ProgressPage(points: points, stars: stars, completed: completed),
      const SettingsPage(),
    ];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.menu_book), label: 'Lessons'),
          NavigationDestination(icon: Icon(Icons.games), label: 'Games'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Progress'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }

  Widget _home() => Padding(
    padding: const EdgeInsets.all(20),
    child: ListView(children: [
      const SizedBox(height: 15),
      const Text('English Kids', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('English Kids in a fun way! 🎉', style: TextStyle(fontSize: 18)),
      const SizedBox(height: 25),
      Card(
        child: Padding(padding: const EdgeInsets.all(20), child: Column(
          children: [
            const Text('🌟', style: TextStyle(fontSize: 60)),
            const Text('Welcome!', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text('$points Points   ⭐ $stars Stars'),
            const SizedBox(height: 15),
            LinearProgressIndicator(value: (completed / 20).clamp(0, 1)),
          ],
        )),
      ),
      const SizedBox(height: 20),
      _bigButton('Start Learning', Icons.play_arrow, () => setState(() => tab = 1)),
      _bigButton('Play Games', Icons.games, () => setState(() => tab = 2)),
      _bigButton('My Progress', Icons.bar_chart, () => setState(() => tab = 3)),
    ]),
  );

  Widget _bigButton(String text, IconData icon, VoidCallback onTap) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: SizedBox(height: 58, child: FilledButton.icon(
      onPressed: onTap, icon: Icon(icon), label: Text(text, style: const TextStyle(fontSize: 18)),
    )),
  );
}

class LessonsPage extends StatelessWidget {
  final VoidCallback onComplete;
  const LessonsPage({super.key, required this.onComplete});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Lessons 📚', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      ...units.entries.map((e) => Card(
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.school)),
          title: Text(e.key, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${e.value.length} words'),
          trailing: const Icon(Icons.arrow_forward_ios),
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => WordLesson(title: e.key, words: e.value, onComplete: onComplete),
          )),
        ),
      )),
    ],
  );
}

class WordLesson extends StatefulWidget {
  final String title; final List<Word> words; final VoidCallback onComplete;
  const WordLesson({super.key, required this.title, required this.words, required this.onComplete});
  @override State<WordLesson> createState() => _WordLessonState();
}

class _WordLessonState extends State<WordLesson> {
  final tts = FlutterTts();
  int index = 0;
  bool rewarded = false;

  Future<void> speak() async {
    await tts.setLanguage('en-US');
    await tts.setSpeechRate(0.42);
    await tts.speak(widget.words[index].en);
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.words[index];
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(w.emoji, style: const TextStyle(fontSize: 100)),
          const SizedBox(height: 20),
          Text(w.en, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.bold)),
          Text(w.ar, style: const TextStyle(fontSize: 24)),
          const SizedBox(height: 25),
          FilledButton.icon(onPressed: speak, icon: const Icon(Icons.volume_up), label: const Text('Listen')),
          const SizedBox(height: 30),
          LinearProgressIndicator(value: (index + 1) / widget.words.length),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () {
              if (index < widget.words.length - 1) {
                setState(() => index++);
              } else if (!rewarded) {
                rewarded = true; widget.onComplete();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Great job! +10 points ⭐')),
                );
              }
            },
            child: Text(index < widget.words.length - 1 ? 'Next' : 'Complete Lesson'),
          ),
        ]),
      ),
    );
  }
}

class GamesPage extends StatelessWidget {
  const GamesPage({super.key});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(padding: const EdgeInsets.all(24), child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text('Games 🎮', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text('Practice English with fun mini-games!'),
        const SizedBox(height: 25),
        FilledButton.icon(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizPage())),
          icon: const Icon(Icons.quiz), label: const Text('Quick Quiz'),
        ),
      ],
    )),
  );
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});
  @override State<QuizPage> createState() => _QuizPageState();
}
class _QuizPageState extends State<QuizPage> {
  final qs = const [
    ('What is "Cat" in Arabic?', ['قطة','كلب','أسد'], 0),
    ('What color is the sky?', ['Green','Blue','Red'], 1),
    ('What is "Apple"?', ['موزة','تفاحة','خبز'], 1),
    ('Which means "أم"?', ['Father','Mother','Sister'], 1),
  ];
  int q = 0, score = 0;
  @override
  Widget build(BuildContext context) {
    final item = qs[q];
    return Scaffold(
      appBar: AppBar(title: const Text('Quick Quiz')),
      body: Padding(padding: const EdgeInsets.all(22), child: Column(
        mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('Question ${q+1}/${qs.length}', style: const TextStyle(fontSize: 18)),
          const SizedBox(height: 18),
          Text(item.$1, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          const SizedBox(height: 25),
          ...List.generate(item.$2.length, (i) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: SizedBox(width: double.infinity, height: 52, child: OutlinedButton(
              onPressed: () {
                if (i == item.$3) score++;
                if (q < qs.length - 1) setState(() => q++);
                else showDialog(context: context, builder: (_) => AlertDialog(
                  title: const Text('Excellent! 🎉'),
                  content: Text('Your score: $score/${qs.length}'),
                  actions: [TextButton(onPressed: () => Navigator.popUntil(context, (r) => r.isFirst), child: const Text('Done'))],
                ));
              }, child: Text(item.$2[i], style: const TextStyle(fontSize: 18)),
            )),
          )),
        ],
      )),
    );
  }
}

class ProgressPage extends StatelessWidget {
  final int points, stars, completed;
  const ProgressPage({super.key, required this.points, required this.stars, required this.completed});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(20),
    child: ListView(children: [
      const Text('My Progress 📊', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      _stat('⭐ Stars', '$stars'),
      _stat('🏆 Points', '$points'),
      _stat('📚 Lessons Completed', '$completed'),
      const SizedBox(height: 20),
      const Text('Level', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Beginner'),
      const SizedBox(height: 8),
      LinearProgressIndicator(value: (completed / 20).clamp(0, 1)),
    ]),
  );
  Widget _stat(String title, String value) => Card(
    child: ListTile(title: Text(title), trailing: Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
  );
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: const [
      Text('Settings ⚙️', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      SizedBox(height: 20),
      Card(child: ListTile(leading: Icon(Icons.volume_up), title: Text('Sound'), trailing: Switch(value: true, onChanged: null))),
      Card(child: ListTile(leading: Icon(Icons.language), title: Text('Language'), subtitle: Text('Arabic / English'))),
      Card(child: ListTile(leading: Icon(Icons.privacy_tip), title: Text('Privacy & Safety'))),
      Card(child: ListTile(leading: Icon(Icons.info), title: Text('About English Kids'))),
    ],
  );
}
