# English Kids

A kid-friendly Flutter app for learning English.

## Run
1. Install Flutter.
2. Run `flutter pub get`.
3. Run `flutter run`.
4. For Android APK: `flutter build apk --release`.

The first version includes lessons, Arabic translations, text-to-speech, a quiz, points, stars, progress, and local storage.
